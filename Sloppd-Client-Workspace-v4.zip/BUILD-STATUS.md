# Sloppd Client build status

This workspace contains a reconstructed Gradle build for the supplied Anubis 0.9.9 source snapshot, renamed to Sloppd Client.

## Fastest build route

The included GitHub Actions workflow (`.github/workflows/build.yml`) builds on Java 21 / Gradle 9.4.1 and publishes the resulting JAR as a downloadable workflow artifact named `Sloppd-Client-test-build`.

After uploading this workspace to a GitHub repository, open **Actions → Build Sloppd Client → Run workflow**. When the run completes, open the run and download the artifact.

## Important limitations

- This environment has Java 21 but no Gradle installation and no outbound network/DNS, so a local Gradle build cannot be run here.
- The original source ZIP is a source snapshot, not the complete original build repository. Build configuration and dependencies have been reconstructed and still require CI validation.
- The supplied snapshot omits most original binary resources (fonts, textures, shaders and other assets). A successful compilation would not by itself prove that the client is fully functional in-game.
- Do not treat a test artifact as a verified release until it launches successfully in Minecraft 1.21.11 with Java 21 and Fabric Loader.
