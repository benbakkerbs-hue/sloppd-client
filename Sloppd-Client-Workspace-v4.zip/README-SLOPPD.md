# Sloppd Client — reconstructed build workspace

Target: Minecraft Java 1.21.11 · Fabric · Java 21
Base: Anubis Client source snapshot 0.9.9

## What is included

- 603 Java source files from the uploaded source snapshot
- Fabric mod metadata and both Mixin configuration files
- Reconstructed Gradle settings/build files
- GPL-3.0 license text
- A temporary Sloppd app icon

## Build configuration evidence

The Anubis project page confirms Minecraft 1.21.11 and Java 21+. A published
static build report for Anubis 0.9.9.1 records Loom 1.16.3, Gradle 9.4.1,
Fabric Loader 0.19.2, and intermediary mappings. These values informed this
reconstruction. The project was not compiled in this environment.

## Build attempt

Use JDK 21 and Gradle 9.4.1, then run:

    gradle clean build

The first build may still fail because the supplied source snapshot omits the
original binary resources/assets and any exact dependency lock state. Save the
full Gradle error output to diagnose remaining dependency or source issues.

## Known limitations

- This is a reconstructed project, not an upstream Git checkout.
- No Gradle Wrapper JAR was included because the original wrapper was absent.
- The icon is a temporary placeholder.
- Build success and in-game behavior have not been verified.
- Module removal and complete Baritone audit remain separate source review tasks.

## License / attribution

This project retains the original GPL-3.0-only license. When redistributing a
derivative, comply with GPL-3.0 source and notice requirements and retain the
credit: "Based on Anubis Client by Horus and 4ldenz" with a link to the upstream
repository.
